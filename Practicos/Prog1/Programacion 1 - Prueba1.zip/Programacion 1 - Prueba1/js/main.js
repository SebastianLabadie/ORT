/* ---------------EJERCICIO 2--------------- */
document.querySelector("#btnCalcular").addEventListener("click", () => {
    const cantDias = parseInt(document.querySelector("#txtNumeroDias").value);
    let precioTotal = 0

    if(cantDias<=5){
    }else{

        if(cantDias <= 10){
            precioTotal = (cantDias-5) * 10
        }else{
            precioTotal = ((cantDias-10) * 20 )+ (5*10)
        }

    }

    document.querySelector("#pSalida").innerHTML = `Tarifa Total: ${precioTotal}`;
  });